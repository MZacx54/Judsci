
export interface Program {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

export interface ImpactStat {
  label: string;
  value: number;
  suffix: string;
}

export interface Resource {
  id: string;
  title: string;
  type: 'Annual Report' | 'Newsletter' | 'Legal Aid';
  date: string;
  downloadUrl: string;
}

export interface BlogPost {
  id: string;
  title: string;
  summary: string;
  category: string;
  date: string;
  imageUrl: string;
}

export enum AppSection {
  HOME = 'home',
  PROGRAMS = 'programs',
  BOOKINGS = 'bookings',
  DONATIONS = 'donations',
  RESOURCES = 'resources',
  NEWS = 'news',
  ADMIN = 'admin'
}


import React from 'react';
import { Program } from '../types';

const PROGRAMS: Program[] = [
  { id: '1', title: 'Peacebuilding', description: 'Conflict resolution and communal harmony projects in volatile zones.', icon: '🤝', color: 'bg-blue-500' },
  { id: '2', title: 'Human Rights', description: 'Legal aid and advocacy for vulnerable populations and prisoners.', icon: '⚖️', color: 'bg-red-500' },
  { id: '3', title: 'Sustainable Agriculture', description: 'Empowering smallholder farmers with modern techniques and seeds.', icon: '🌱', color: 'bg-green-500' },
  { id: '4', title: 'Education & Literacy', description: 'Adult education and vocational training programs for youth.', icon: '📚', color: 'bg-purple-500' },
  { id: '5', title: 'Clean Water & Sanitation', description: 'Construction of solar-powered boreholes in remote LGAs.', icon: '🚰', color: 'bg-sky-500' },
  { id: '6', title: 'Governance & Democracy', description: 'Civic education and monitoring of electoral processes.', icon: '🗳️', color: 'bg-orange-500' },
];

interface ProgramGridProps {
  onSelect?: () => void;
  fullView?: boolean;
}

const ProgramGrid: React.FC<ProgramGridProps> = ({ onSelect, fullView }) => {
  return (
    <section className={`py-20 ${fullView ? 'bg-gray-50' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Areas of Work</h2>
        <p className="text-gray-500 max-w-2xl mx-auto mb-16">
          Our thematic interventions are designed to address the most pressing needs of Bauchi State citizens.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
          {PROGRAMS.map((prog) => (
            <div 
              key={prog.id} 
              className="group bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-2xl transition-all cursor-pointer transform hover:-translate-y-2"
              onClick={onSelect}
            >
              <div className={`w-14 h-14 ${prog.color} text-white text-3xl flex items-center justify-center rounded-2xl mb-6 shadow-lg group-hover:scale-110 transition-transform`}>
                {prog.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 group-hover:text-green-700 transition-colors">{prog.title}</h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                {prog.description}
              </p>
              <button className="text-sm font-bold text-green-700 flex items-center group-hover:gap-2 transition-all">
                Learn More 
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProgramGrid;


import React from 'react';

interface HeroProps {
  onAction: () => void;
}

const Hero: React.FC<HeroProps> = ({ onAction }) => {
  return (
    <section className="relative h-[80vh] flex items-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/id/11/1920/1080" 
          className="w-full h-full object-cover filter brightness-[0.4]"
          alt="Bauchi Landscape"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-green-900/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
        <div className="max-w-2xl animate-in slide-in-from-left duration-1000">
          <span className="inline-block px-3 py-1 bg-yellow-500/90 text-yellow-950 font-bold text-xs rounded-full mb-6 tracking-wider uppercase">
            Official Platform of JDPC Bauchi
          </span>
          <h1 className="text-5xl md:text-7xl font-extrabold leading-tight mb-6">
            Justice. Development. <span className="text-yellow-400">Peace.</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-100 mb-8 font-light leading-relaxed">
            Advancing the dignity of the human person and fostering sustainable communities across Bauchi State.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={onAction}
              className="px-8 py-4 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl shadow-lg transition-all transform hover:-translate-y-1 active:scale-95"
            >
              Support Our Mission
            </button>
            <button className="px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white font-bold rounded-xl border border-white/30 transition-all">
              Watch Our Impact
            </button>
          </div>
        </div>
      </div>

      {/* Stats preview floating at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-gray-950/80 to-transparent"></div>
    </section>
  );
};

export default Hero;

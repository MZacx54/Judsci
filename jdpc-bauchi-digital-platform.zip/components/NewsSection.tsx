
import React from 'react';
import { BlogPost } from '../types';

const POSTS: BlogPost[] = [
  { id: '1', title: 'New Peace Initiative Launches in Tafawa Balewa', summary: 'JDPC Bauchi brings together community leaders to sign a historical peace accord.', category: 'Peacebuilding', date: '2023-11-05', imageUrl: 'https://picsum.photos/id/10/800/600' },
  { id: '2', title: 'Success Story: From Prisoner to Entrepreneur', summary: 'How our legal aid and vocational training transformed Malam Danjuma\'s life.', category: 'Success Story', date: '2023-10-22', imageUrl: 'https://picsum.photos/id/12/800/600' },
  { id: '3', title: 'Empowering 500 Women Farmers in Alkaleri', summary: 'A distribution of drought-resistant seeds marks the start of the planting season.', category: 'Agriculture', date: '2023-10-15', imageUrl: 'https://picsum.photos/id/15/800/600' },
];

interface NewsSectionProps {
  fullView?: boolean;
}

const NewsSection: React.FC<NewsSectionProps> = ({ fullView }) => {
  return (
    <section className={`py-20 ${fullView ? 'bg-white' : 'bg-gray-50'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-3xl font-bold mb-2">News & Updates</h2>
            <p className="text-gray-500">The latest field stories from our missions across Bauchi.</p>
          </div>
          {!fullView && (
            <button className="text-green-700 font-bold hover:underline">View All Posts &rarr;</button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {POSTS.map(post => (
            <article key={post.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all group">
              <div className="h-56 overflow-hidden relative">
                <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <span className="absolute top-4 left-4 px-3 py-1 bg-green-700 text-white text-xs font-bold rounded-lg shadow-lg">
                  {post.category}
                </span>
              </div>
              <div className="p-8">
                <div className="text-xs font-bold text-gray-400 mb-3">{new Date(post.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</div>
                <h3 className="text-xl font-bold mb-4 group-hover:text-green-700 transition-colors">{post.title}</h3>
                <p className="text-gray-600 line-clamp-2 text-sm leading-relaxed mb-6">
                  {post.summary}
                </p>
                <button className="text-sm font-black text-gray-900 flex items-center gap-2 group-hover:gap-4 transition-all">
                  Read Full Story
                  <svg className="w-4 h-4 text-green-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewsSection;


import React, { useEffect, useState } from 'react';
import { ImpactStat } from '../types';

const STATS: ImpactStat[] = [
  { label: 'Lives Touched', value: 12000, suffix: '+' },
  { label: 'Peace Accords', value: 45, suffix: '' },
  { label: 'LGAs Reached', value: 20, suffix: '/20' },
  { label: 'Legal Aid Cases', value: 850, suffix: '+' },
];

const ImpactCounters: React.FC = () => {
  const [counts, setCounts] = useState(STATS.map(() => 0));

  useEffect(() => {
    const duration = 2000; // 2 seconds animation
    const frameRate = 30;
    const totalFrames = duration / (1000 / frameRate);
    
    let frame = 0;
    const interval = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      const easeOutQuad = (t: number) => t * (2 - t);
      
      const newCounts = STATS.map(stat => Math.floor(stat.value * easeOutQuad(progress)));
      setCounts(newCounts);

      if (frame >= totalFrames) {
        clearInterval(interval);
        setCounts(STATS.map(stat => stat.value));
      }
    }, 1000 / frameRate);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {STATS.map((stat, idx) => (
            <div key={idx} className="text-center p-6 rounded-2xl bg-gray-50 border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="text-4xl md:text-5xl font-black text-green-700 mb-2">
                {counts[idx].toLocaleString()}{stat.suffix}
              </div>
              <div className="text-sm md:text-base font-semibold text-gray-500 uppercase tracking-widest">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImpactCounters;
